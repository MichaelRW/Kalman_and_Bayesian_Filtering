% Pr24_1.m 
% Cascade of a Dynamic Linear System 
% (low pass filter from pr17_1.m 
% and a (Static) Squarer (see Figure 24.2A)
% This type of system is a so-called Wiener Cascade 

clear
close all

% Linear component is a low-pass RC circuit
% we use R=10k and C=3.3uF
R=10e3;
C=3.3e-6;
RC=R*C;

% Timing parameters
sample_rate=1000; 
dt=1/sample_rate;
time=0.1;
A=RC/dt;
T=100;          % The setting for timing and the length of correlation 
                % calculations for both Volterra and Wiener kernels

% WARNING
msg=['WARNING : RC/dt is: ' num2str(RC/dt) ' \n RC/dt should be >> 1 to obtain high precision of the discrete time solution. \n A poor match will be obtained between the continuous \n time and discrete time AROUND t~0 IF RC/dt IS TOO SMALL, \n PRESS ENTER TO CONTINUE'];
WARNING=input(msg);

% 1. The analog continuous time approach using the square of
% the unit impulse response of the filter: h(t)=(1/RC)*exp(-t/RC)
% to compare with discrete time approach (in the following Steps) we assume
% the discrete time steps (dt) and interval (time)
j=1;
for tau1=0:dt:time;
    i=1;
    r1(j)=(1/RC)*exp(-tau1/RC);     % 1st-order response in the cascade
                                    
    for tau2=0:dt:time
        y(i,j)=((1/RC)*exp(-tau1/RC))*((1/RC)*exp(-tau2/RC));
                            % Output y is h2 (=2nd order Volterra kernel) 
                            % which is the square of the filter response
        i=i+1;
    end;
    j=j+1;
end;

% plot the surface of h2
y=y*dt^2;                   % scale for the sample value dt 
figure; surf(y); 
axis([0 T 0 T min(min(y)) max(max(y))])
view(100,50)
title('2nd order Volterra kernel (h2) of an LN cascade')
xlabel('tau1');ylabel('tau2');zlabel('h2');

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%   2. The difference equation mode (see pr17_1.m)
%   Using Equation (16.9)in Section 16.2.2: y(n)=(A*y_previous+x(n))/(A+1)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

x=zeros(1,100);x(1)=1; 
% the input is an impulse at t=0 
% we do NOT correct the input with 1/dt 
% because we already corrected y for sample rate on line 47

y_previous=0;
for n=1:length(x);
    yh(n)=(A*y_previous+x(n))/(A+1); % the linear component
    y_previous=yh(n);
    z(n)=yh(n)^2;                    % the squarer
end;

figure;
hold;
plot(z,'r');         % plot the unit impulse response
title(' Unit Impulse Response: red-measured; green triangels-diagonal of kernel h2')
xlabel(' Time')
ylabel(' Unit Impulse Response')
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%   3. Compare the results in Step 1 and Step 2
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

for i=1:length(x);
    diag(i)=y(i,i); % the diagonal of the 2 dimensional kernel y
                    % is the unit impulse response z
end; 

plot(diag,'gv')     % superimpose with green triangels

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%   4. Determine response for delayed unit impulse 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

figure;
hold;
for delay=5:5:length(x);

    x=zeros(1,length(x));x(delay)=1;  
    % the input is an impulse at t=0 
    % we do NOT correct the input with 1/dt 
    % because we already corrected y for sample rate on line 47
    
    y_previous=0;
    for n=1:length(x);
        yh(n)=(A*y_previous+x(n))/(A+1); % the linear component
        y_previous=yh(n);
        z(n)=yh(n)^2;                    % the squarer
    end;

    plot(z,'r')         % plot the delayed unit impulse response
end;
title(' Responses upon Delayed Unit Impulses')
xlabel(' Time')
ylabel(' Response')
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%     5. determine the response to the sum of two unit impulses: 
%     each with its own delay and the response of the unit
%     impulse individually, 
%     compute h2 kernel slices along 45 deg lines from these
%     using STEPS 1-6 in Section 24.3
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

figure;hold;

delay1=1;  
for delay2=delay1:1:length(x);
    x1=zeros(1,100);x1(delay1)=1;     %  unit impulse with delay 1
    x2=zeros(1,100);x2(delay2)=1;     %  unit impulse with delay 2
% The summed input xs, containing two unit impulses
    if (delay1==delay2);
        xs=zeros(1,100);xs(delay1)=2; % delays are equal
    else
        xs=zeros(1,100);xs(delay1)=1;xs(delay2)=1;     
                                      % sum of two unit impulses if delays 
                                      % are NOT equal
    end;
% Compute the system outputs to individual and combined unit impulses    
    y1_previous=0;
    y2_previous=0;
    ys_previous=0;
    
    for n=1:length(x);
        % reponse to delay1
        y1(n)=(A*y1_previous+x1(n))/(A+1);  % the linear component
        y1_previous=y1(n);
        z1(n)=y1(n)^2;                      % the squarer
        % response to delay2
        y2(n)=(A*y2_previous+x2(n))/(A+1);  % the linear component
        y2_previous=y2(n);
        z2(n)=y2(n)^2;                      % the squarer
        % reponse to the sum of both delays
        ys(n)=(A*ys_previous+xs(n))/(A+1);  % the linear component
        ys_previous=ys(n);
        zs(n)=ys(n)^2;                      % the squarer
    end;
  
    h=(zs-z1-z2)/2;         % A slice of the kernel h2
                            % in the tau1-tau2 plane this is a line
                            % at 45 degrees with intersection delay1-delay2
    tau1=delay2:1:length(x);
    tau2=tau1+(delay1-delay2);
    h=h(delay2:length(h));
       
    plot3(tau1,tau2,h); 
    
end;

axis([0 T 0 T])
view(100,50)
title('half of 2nd order Volterra kernel (h2) of an LN cascade')
xlabel('tau1');ylabel('tau2');zlabel('h2');
grid on