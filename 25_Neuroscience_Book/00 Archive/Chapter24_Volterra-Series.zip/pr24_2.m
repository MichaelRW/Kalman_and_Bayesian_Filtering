% Pr24_2.m
% A 2nd-order system (Fig. 24.2C)consisting of
% 1st-order operator H1
%       and
% 2nd-order operator H2 which is a
% cascade of a Linear System 
% (low pass filter from pr17_1.m) 
% and a Squarer (see Figure 24.2A)

clear
close all

% Linear component is a low-pass RC circuit

R1=15e2;
C=3.3e-6;
RC1=R1*C;       % RC circuit in the 1st order component

R2=5e2;
RC2=R2*C;       % RC circuit in the 2nd order component

% Timing parameters
sample_rate=1000; 
dt=1/sample_rate;
time=0.1;

A1=RC1/dt;
A2=RC2/dt;

T=32;                   % The setting for the length of correlation 
                        % calculations for both Volterra and Wiener kernels

                        
% WARNING
msg=['WARNING : RC1/dt and RC2/dt are: ' num2str(RC1/dt) ' and ' num2str(RC2/dt) '\n RC/dt should be >> 1 to obtain high precision of the discrete time solution. \n A poor match will be obtained between the continuous \n time and discrete time AROUND t~0 IF RC/dt IS TOO SMALL, \n PRESS ENTER TO CONTINUE'];
WARNING=input(msg);
                        
% 1. The analog continuous time approach for determining h2
% using the square of the unit impulse of the filter: 
%               h2(t)=(1/RC2)*exp(-t/RC2)
% to compare with discrete time approach (in the following Steps) we use
% the discrete time steps (dt) and interval (time)in the computation
j=1;
for tau1=0:dt:time;
    i=1;
    for tau2=0:dt:time
        y(i,j)=((1/RC2)*exp(-tau1/RC2))*((1/RC2)*exp(-tau2/RC2));    
        %  y is  h2 (= 2nd order Volterra kernel) 
        i=i+1;
    end;
    j=j+1;
end;
y=y*dt^2;               % scale for the sample value dt 
% plot the surface of h2
figure; surf(y)
axis([0 T 0 T min(min(y)) max(max(y))])
view(100,50)
title('2nd order Volterra kernel (h2): theoretical')
xlabel('tau1');ylabel('tau2');zlabel('h2');

%   2. The difference equation mode to compute the 
%   unit impulse response (see also pr24_1.m)
%   Equation (16.9)in Section 16.2.2: 
%                   y(n)=(A*y_previous+x(n))/(A+1)


x=zeros(1,100);x(1)=1;      % the input is an impulse at t=0 

y_previous1=0;
y_previous2=0;
for n=1:length(x);
    yh1(n)=(A1*y_previous1+x(n))/(A1+1);        % the 1st order operator
    y_previous1=yh1(n);
    yh2(n)=(A2*y_previous2+x(n))/(A2+1);        % the linear component in the 2nd order operator
    y_previous2=yh2(n);
    zz(n)=yh1(n)+yh2(n)^2;                      % the squarer + 1st order component
end;

figure;
hold;
plot(zz,'r.-')      % plot the unit impulse response of 
                    % the combined operators H1 and H2
plot(yh1,'k')       % 1st order component of the unit impulse response 
YH1=yh1;            % save the theoretical 1st order for later comparisons
plot(yh2.^2,'g')    % 2nd order component of the unit impulse response
title(' Unit Impulse Response; red-total response; black-1st order; green-2nd order')
xlabel(' Time')
ylabel(' Unit Impulse Response')
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%   3. Compare the results in Step 1 and Step 2
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

for i=1:length(x);
    diag(i)=y(i,i); % the diagonal of the 2 dimensional kernel y (=h2)
                    % is the unit impulse response of the 2nd order
                    % component
end; 

plot(diag,'gv')     % superimpose with green triangels
h1=zz-diag;
plot(h1,'kv')       % the difference between the total unit impulse response (zz)
                    % and the contribution of the 2nd order component (diag)is
                    % again the 1st order component

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%   4. Determine response for delayed unit impulse 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

figure;
hold;
for delay=5:5:length(x);

    x=zeros(1,length(x));x(delay)=1; 
    y_previous1=0;
    y_previous2=0;
    for n=1:100;
        yh1(n)=(A1*y_previous1+x(n))/(A1+1);        % the 1st order operator
        y_previous1=yh1(n);
        yh2(n)=(A2*y_previous2+x(n))/(A2+1);        % the linear component in the 2nd order operator
        y_previous2=yh2(n);
        z(n)=yh1(n)+yh2(n)^2;                       % the squarer + 1st order component
    end;

    plot(z,'r')         % plot the delayed unit impulse responses
end;
title(' Unit Impulse Responses upon Delayed Unit Impulses')
xlabel(' Time')
ylabel(' Response')

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%     5. determine the response to the sum of two unit impulses: 
%     each with its own delay and the response of the unit
%     impulse individually, 
%     compute h2 kernel slices along 45 deg lines from these
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

figure;hold;

delay1=1;  
for delay2=delay1:1:length(x);
    
    x1=zeros(1,length(x));x1(delay1)=1;     %  unit impulse with delay 1
    x2=zeros(1,length(x));x2(delay2)=1;     %  unit impulse with delay 2
    if (delay1==delay2);
        xs=zeros(1,100);xs(delay1)=2;    % delays are equal the impulse add up 2
    else
        xs=zeros(1,100);xs(delay1)=1;xs(delay2)=1;     
                    % sum of two unit impulses if delays are NOT equal

    end;
    
    y1_previous1=0;y1_previous2=0;
    y2_previous1=0;y2_previous2=0;
    ys_previous1=0;ys_previous2=0;
    
    for n=1:100;
        % reponse to delay1
        y1h1(n)=(A1*y1_previous1+x1(n))/(A1+1);        % the 1st order operator
        y1_previous1=y1h1(n);
        y1h2(n)=(A2*y1_previous2+x1(n))/(A2+1);        % the linear component in the 2nd order operator
        y1_previous2=y1h2(n);
        z1(n)=y1h1(n)+y1h2(n)^2;                       % the squarer + 1st order component
        % response to delay2
        y2h1(n)=(A1*y2_previous1+x2(n))/(A1+1);        % the 1st order operator
        y2_previous1=y2h1(n);
        y2h2(n)=(A2*y2_previous2+x2(n))/(A2+1);        % the linear component in the 2nd order operator
        y2_previous2=y2h2(n);
        z2(n)=y2h1(n)+y2h2(n)^2;                       % the squarer + 1st order component
        % reponse to the sum of both delays
        ysh1(n)=(A1*ys_previous1+xs(n))/(A1+1);        % the 1st order operator
        ys_previous1=ysh1(n);
        ysh2(n)=(A2*ys_previous2+xs(n))/(A2+1);        % the linear component in the 2nd order operator
        ys_previous2=ysh2(n);
        zs(n)=ysh1(n)+ysh2(n)^2;                       % the squarer + 1st order component
    end;
    
    h2=(zs-z1-z2)/2;        % A slice of the kernel h2
                            % in the tau1-tau2 plane this is a line
                            % at 45 degrees with intersection delay1-delay2
    tau1=delay2:1:100;
    tau2=tau1+(delay1-delay2);
    h2=h2(delay2:length(h2));
    
    if (delay1==delay2)
        h_1=zz-h2;     % for equal delays (delay1=delay2)
                       % the 1st order kernel is the difference
                       % between the impulse response z (determined in 
                       % step 2 above)and h2
    end;
    
    plot3(tau1,tau2,h2); 
    
end;

axis([0 T 0 T])
view(100,50)
title('Measured half of the 2nd order Volterra kernel (h2) of a 2nd order Nonlinear System')
xlabel('tau1');ylabel('tau2');zlabel('h2');
grid on

figure;
subplot(2,1,1),plot(h_1,'r');hold;plot(YH1,'gv')
title('1st order kernel h1: red-measured; green-theoretical')
subplot(2,1,2),surf(y);axis([0 T 0 T]);view(100,50)
title('2nd order kernel h2')
