% pr25_1.m : Wienermodel
% 
% Cascade of a Dynamic Linear System 
% Low pass filter from pr17_1.m 
% and a (Static) Squarer 
% This type of system is a so-called Wiener Model 

clear
close all

% Linear component is a low-pass RC circuit
% we use R=10k and C=3.3uF
R=1e3;
C=3.3e-6;
RC=R*C;

% Timing parameters
sample_rate=1000; 
dt=1/sample_rate;
time=0.1;
A=RC/dt;
T=32;                   % The setting for the length of correlation 
                        % calculations for both Volterra and Wiener kernels
% WARNING
(['RCdt is: ' num2str(RC/dt)])
('RC/dt should be >> 1 to obtain high precision of the concrete')
('time solution. A poor match will be obtained between the continuous')
('time and discrete time AROUND t~0 IF RC/dt IS SMALL, ')
('ANY KEY TO CONTINUE')
pause;

% 1. The analog continuous time approach using the square of
% the unit impulse of the filter: h(t)=(1/RC)*exp(-t/RC)
% to compare with discrete time approach (in the following Steps) we assume
% the discrete time steps (dt) and interval (time)
j=1;
for tau1=0:dt:time;
    i=1;
    r1(j)=(1/RC)*exp(-tau1/RC);     % 1st-order response in the cascade
                                    % not used because it is included in
                                    % the cascade
    for tau2=0:dt:time
        y(i,j)=((1/RC)*exp(-tau1/RC))*((1/RC)*exp(-tau2/RC));
        % Output y is h2 (=2nd order Volterra kernel) 
        % which is the square of h
        i=i+1;
    end;
    j=j+1;
end;

% plot the surface of h2
y=y*dt^2;               % scale for the sample value dt 
                        % see also Westwick and Kearney p.60
figure; surf(y); 
axis([0 T 0 T min(min(y)) max(max(y))])
view(100,50)
title('2nd order Volterra kernel (h2) of an LN cascade')
xlabel('tau1');ylabel('tau2');zlabel('h2');

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%   2. The difference equation mode (pr17_1.m and
%   using Equation (16.9)in Section 16.2.2: y(n)=(A*y_previous+x(n))/(A+1)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

x=zeros(1,100);x(1)=1; 
% the input is an impulse at t=0 
% we do NOT correct the input with 1/dt 
% because we already corrected y for sample rate on line 52

y_previous=0;
for n=1:length(x);
    yh(n)=(A*y_previous+x(n))/(A+1); % the linear component
    y_previous=yh(n);
    z(n)=yh(n)^2;                    % the squarer
end;

figure;
hold;
plot(z,'r');         % plot the unit impulse response
title(' Unit Impulse Response: red-measured; green triangels-diagonal of kernel h2')
xlabel(' Time')
ylabel(' Unit Impulse Response')
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%   3. Compare the results in Step 1 and Step 2
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

for i=1:length(x);
    diag(i)=y(i,i); % the diagonal of the 2 dimensional kernel y
                    % is the unit impulse response z
end; 

plot(diag,'gv')     % superimpose with green triangels

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% 4. Determine response for delayed unit impulse 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

figure;
hold;
for delay=5:5:length(x);

    x=zeros(1,length(x));x(delay)=1;  
    % the input is an impulse at t=0 
    % we do NOT correct the input with 1/dt 
    % because we already corrected y for sample rate on line 52
    
    y_previous=0;
    for n=1:length(x);
        yh(n)=(A*y_previous+x(n))/(A+1); % the linear component
        y_previous=yh(n);
        z(n)=yh(n)^2;                    % the squarer
    end;

    plot(z,'r')         % plot the delayed unit impulse response
end;
title(' Responses upon Delayed Unit Impulses')
xlabel(' Time')
ylabel(' Response')
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% 5. determine the response to the sum of two unit impulses: 
%     each with its own delay and the response of the unit
%     impulse individually, 
%     compute h2 kernel slices along 45 deg lines from these
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

figure;hold;

i=1;j=0;
delay1=1;  
    
for delay2=delay1:1:length(x);
    j=j+1;
    
    x1=zeros(1,100);x1(delay1)=1;     %  unit impulse train with delay 1
    x2=zeros(1,100);x2(delay2)=1;     %  unit impulse train with delay 2
    if (delay1==delay2);
        xs=zeros(1,100);xs(delay1)=2;    % delays are equal
    else
        xs=zeros(1,100);xs(delay1)=1;xs(delay2)=1;     
                                    % sum of two unit impulses if delays are NOT equal
                                    % the input is an impulse at t=T1 we correct the input            
                                    % with 1/dt (see pr12_1.m)
    end;
    
    y1_previous=0;
    y2_previous=0;
    ys_previous=0;
    
    for n=1:length(x);
        % reponse to delay1
        y1(n)=(A*y1_previous+x1(n))/(A+1); % the linear component
        y1_previous=y1(n);
        z1(n)=y1(n)^2;                      % the squarer
        % response to delay2
        y2(n)=(A*y2_previous+x2(n))/(A+1); % the linear component
        y2_previous=y2(n);
        z2(n)=y2(n)^2;                      % the squarer
        % reponse to the sum of both delays
        ys(n)=(A*ys_previous+xs(n))/(A+1); % the linear component
        ys_previous=ys(n);
        zs(n)=ys(n)^2;                      % the squarer
    end;
        
    h=(zs-z1-z2)/2;         % A slice of the kernel h2
                            % in the tau1-tau2 plane this is a line
                            % at 45 degrees with intersection delay1-delay2
    tau1=delay2:1:length(x);
    tau2=tau1+(delay1-delay2);
    h=h(delay2:length(h));
       
    plot3(tau1,tau2,h); 
    
end;

axis([0 T 0 T])
view(100,50)
title('half of 2nd order Volterra kernel (h2) of an LN cascade')
xlabel('tau1');ylabel('tau2');zlabel('h2');
grid on

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% WIENER KERNELS
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%% Estimation of the Wiener kernel estimation using
%%%%%%%%%%%%%%% The Lee, Schetzen cross-correlation method
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% First create a set of input output using random noise

xw=randn(10000,1);          % create array with Gaussian white noise
xw=xw-mean(xw);
N=length(xw);
st=std(xw);

figure;subplot(2,1,1),plot(xcorr(xw),'k');
title('Autocorrelation of the Input Shows a Random Noise Characteristic');
subplot(2,1,2);hist(xw);
title('Amplitude Distribution --> Gaussian');

yw_previous=0;
for n=1:length(xw);
    ywh(n)=(A*yw_previous+xw(n))/(A+1);     % the linear component
    yw_previous=ywh(n);
    zw(n)=ywh(n)^2;                         % the squarer
end;

figure; hold;
plot(xw,'k');plot(zw,'r')
title('Input (black) and Output (red) of a Wiener System')
xlabel('Time (ms)');ylabel('Amplitude')

%%%%%%%%%%%% %%%%%%%%%%%%%%%%%%The Lee Schetzen Cross-correlation Method
%%%%%%%%%%%% ------------------------------------------------------------
% Step 1 (Fig. 25.3): Determine 0-order Wiener kernel
%---------------------------------------------------
k0=mean(zw);
y0=ones(1,length(xw))*k0;
% Step 2 (Fig. 25.3): Subtract k0 from the response
%-------------------------------------------------
v0=zw-k0;
% Step 3 (Fig. 25.3): Estimate k1 by 1st-order 
%                    cross-correlation of v0 and input
%-----------------------------------------------------
 
for i=0:T-1
    temp=0;
    for n=i+1:N
        temp=temp+v0(n)*xw(n-i);
    end;
    k1(i+1)=temp/(N*st^2);
end;

figure; plot(k1);
title(' 1st-order Wiener kernel (NOTE: 1st order part ~ 0)')

% Step 4 (Fig. 25.3): Compute the output of the 1st-order 
%         Wiener kernel using convolution 
%-------------------------------------------------------

for n=1:N;
    temp=0;
    for i=0:min([n-1 T-1]);
        temp=temp+k1(i+1)*xw(n-i);
    end;
    y1(n)=temp;
end;

% Step 5 (Fig. 25.3): Compute the 1st-order residue
%-------------------------------------------------
v1=v0-y1;

% Step 6 (Fig. 25.3): Estimate k2 by 2nd-order 
%                    cross-correlation of v1 with the input
%----------------------------------------------------------
 
for i=0:T-1
    for j=0:i
        
        temp=0;
        for n=i+1:N
            temp=temp+v1(n)*xw(n-i)*xw(n-j);
        end;
        
        k2(i+1,j+1)=temp/(2*N*st^4);
        k2(j+1,i+1)=k2(i+1,j+1);
    
    end;
end;

figure; surf(k2(1:T,1:T));
title('2nd-Order Wiener Kernel');
view(100,50);

% Step 7: Compute the output of the 2nd-order 
%         Wiener kernel using 2nd order convolution 
%--------------------------------------------------

for n=1:N;
    temp=0;
    for i=0:min([n-1 T-1]);
        for j=0:min([n-1 T-1]);
            temp=temp+k2(i+1,j+1)*xw(n-i)*xw(n-j);
        end;
    end;
    y2(n)=temp;
    
    temp=0;
   for i=0:min([n-1 T-1]);
        temp=temp+k2(i+1,i+1);
    end;
    
    ys(n)=temp*st^2;
    Y2(n)=y2(n)-ys(n);

end;
        
figure; 
hold;
est=y0+y1+Y2;
plot(est,'g');
plot(zw,'r');
title('Output (red) Computed Contributions of 0th, 1st, 2nd Order Wiener Kernels (green)')
xlabel('Time (ms)');
ylabel('Amplitude');

% Variance Accounted for: 100% at perfect fit 
('Percentage Variance Accounted for : ')
VAF=(1-(std(zw-est)^2)/(std(zw)^2))*100
